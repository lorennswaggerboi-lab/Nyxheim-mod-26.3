package com.nyxheim;

import com.nyxheim.portal.NyxPortal;
import com.nyxheim.registry.ModBlocks;
import com.nyxheim.registry.ModEntities;
import com.nyxheim.registry.ModItems;
import com.nyxheim.world.NyxSpawner;
import com.nyxheim.world.NyxWorldgen;
import net.fabricmc.api.ModInitializer;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Nyxheim implements ModInitializer {
    public static final String MOD_ID = "nyxheim";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Clave de la dimensión (definida en data/nyxheim/dimension/nyx.json). */
    public static final ResourceKey<Level> NYX = ResourceKey.create(Registries.DIMENSION, id("nyx"));

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();
        ModEntities.init();
        NyxPortal.init();
        NyxWorldgen.init();
        NyxSpawner.init();
        LOGGER.info("Nyxheim cargado: el portal te espera.");
    }
}

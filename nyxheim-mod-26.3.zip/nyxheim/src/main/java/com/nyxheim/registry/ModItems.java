package com.nyxheim.registry;

import com.nyxheim.Nyxheim;
import com.nyxheim.item.EyeOfNyxItem;
import com.nyxheim.item.NyxSigilItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;

import java.util.function.Function;

public final class ModItems {
    public static final TagKey<Item> VOIDITE_REPAIR = TagKey.create(Registries.ITEM, Nyxheim.id("voidite_repair"));

    public static final ToolMaterial VOIDITE_MATERIAL = new ToolMaterial(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 2400, 9.0f, 4.0f, 18, VOIDITE_REPAIR);

    public static final Item RAW_VOIDITE = reg("raw_voidite", Item::new, new Item.Properties());
    public static final Item VOIDITE_INGOT = reg("voidite_ingot", Item::new, new Item.Properties());
    public static final Item LUNARITE_SHARD = reg("lunarite_shard", Item::new, new Item.Properties());
    public static final Item EYE_OF_NYX = reg("eye_of_nyx", EyeOfNyxItem::new, new Item.Properties().stacksTo(1));
    public static final Item NYX_SIGIL = reg("nyx_sigil", NyxSigilItem::new, new Item.Properties().stacksTo(1));
    public static final Item NYX_APPLE = reg("nyx_apple", Item::new, new Item.Properties().food(
            new FoodProperties.Builder().nutrition(8).saturationModifier(1.2f).alwaysEdible().build()));
    public static final Item VOIDITE_SWORD = reg("voidite_sword", Item::new,
            new Item.Properties().sword(VOIDITE_MATERIAL, 3.0f, -2.4f));
    public static final Item VOIDITE_PICKAXE = reg("voidite_pickaxe", Item::new,
            new Item.Properties().pickaxe(VOIDITE_MATERIAL, 1.0f, -2.8f));

    private static Item reg(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Nyxheim.id(name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(e -> {
            e.accept(RAW_VOIDITE); e.accept(VOIDITE_INGOT); e.accept(LUNARITE_SHARD);
            e.accept(EYE_OF_NYX); e.accept(NYX_SIGIL);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FOOD_AND_DRINKS).register(e -> e.accept(NYX_APPLE));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(e -> e.accept(VOIDITE_SWORD));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(e -> e.accept(VOIDITE_PICKAXE));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(e -> {
            e.accept(ModBlocks.NYX_STONE); e.accept(ModBlocks.NYX_BRICKS); e.accept(ModBlocks.NYX_PLANKS);
            e.accept(ModBlocks.VOIDITE_BLOCK); e.accept(ModBlocks.LUNARITE_BLOCK);
            e.accept(ModBlocks.RUNED_OBSIDIAN); e.accept(ModBlocks.NYX_CORE_BLOCK); e.accept(ModBlocks.GLOW_CRYSTAL);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.NATURAL_BLOCKS).register(e -> {
            e.accept(ModBlocks.NYX_GRASS_BLOCK); e.accept(ModBlocks.NYX_DIRT); e.accept(ModBlocks.NYX_LOG);
            e.accept(ModBlocks.NYX_LEAVES); e.accept(ModBlocks.VOIDITE_ORE); e.accept(ModBlocks.LUNARITE_ORE);
        });
    }
}

package com.nyxheim.client;

import com.nyxheim.Nyxheim;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.client.renderer.entity.state.ZombieRenderState;
import net.minecraft.resources.Identifier;

/** Reutiliza el modelo de zombi de vanilla con una textura propia. */
public class NyxZombieRenderer extends ZombieRenderer {
    private final Identifier texture;

    public NyxZombieRenderer(EntityRendererProvider.Context context, String textureName) {
        super(context);
        this.texture = Nyxheim.id("textures/entity/" + textureName + ".png");
    }

    @Override
    public Identifier getTextureLocation(ZombieRenderState state) {
        return texture;
    }
}

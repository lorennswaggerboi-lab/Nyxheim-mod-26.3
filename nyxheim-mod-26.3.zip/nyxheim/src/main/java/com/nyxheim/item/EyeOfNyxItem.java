package com.nyxheim.item;

import com.nyxheim.portal.NyxPortal;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

/** La llave del portal: se usa sobre el marco completo (Obsidiana Rúnica + 4 Núcleos de Nyx). */
public class EyeOfNyxItem extends Item {
    public EyeOfNyxItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        var level = context.getLevel();
        Player player = context.getPlayer();
        if (NyxPortal.tryActivate(level, context.getClickedPos())) {
            if (player != null && !player.getAbilities().instabuild) {
                context.getItemInHand().shrink(1);
            }
            return InteractionResult.SUCCESS;
        }
        if (player != null) {
            player.displayClientMessage(Component.translatable("message.nyxheim.bad_frame"), true);
        }
        return InteractionResult.FAIL;
    }
}

package com.nyxheim.registry;

import com.nyxheim.Nyxheim;
import com.nyxheim.block.NyxPortalBlock;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

import java.util.function.Function;

public final class ModBlocks {
    private static BlockBehaviour.Properties p() { return BlockBehaviour.Properties.of(); }

    public static final Block NYX_STONE = reg("nyx_stone", Block::new,
            p().mapColor(MapColor.COLOR_BLACK).strength(2.2f, 6f).sound(SoundType.DEEPSLATE).requiresCorrectToolForDrops());
    public static final Block NYX_BRICKS = reg("nyx_bricks", Block::new,
            p().mapColor(MapColor.COLOR_BLACK).strength(2.5f, 7f).sound(SoundType.DEEPSLATE_BRICKS).requiresCorrectToolForDrops());
    public static final Block NYX_DIRT = reg("nyx_dirt", Block::new,
            p().mapColor(MapColor.COLOR_PURPLE).strength(0.5f).sound(SoundType.GRAVEL));
    public static final Block NYX_GRASS_BLOCK = reg("nyx_grass_block", Block::new,
            p().mapColor(MapColor.COLOR_PURPLE).strength(0.6f).sound(SoundType.GRASS));
    public static final Block NYX_LOG = reg("nyx_log", RotatedPillarBlock::new,
            p().mapColor(MapColor.COLOR_PURPLE).strength(2f).sound(SoundType.WOOD));
    public static final Block NYX_PLANKS = reg("nyx_planks", Block::new,
            p().mapColor(MapColor.COLOR_PURPLE).strength(2f, 3f).sound(SoundType.WOOD));
    public static final Block NYX_LEAVES = reg("nyx_leaves", Block::new,
            p().mapColor(MapColor.COLOR_MAGENTA).strength(0.2f).sound(SoundType.GRASS).lightLevel(s -> 5));

    public static final Block VOIDITE_ORE = reg("voidite_ore", props -> new DropExperienceBlock(UniformInt.of(3, 7), props),
            p().mapColor(MapColor.COLOR_BLACK).strength(4f, 6f).sound(SoundType.DEEPSLATE).requiresCorrectToolForDrops());
    public static final Block LUNARITE_ORE = reg("lunarite_ore", props -> new DropExperienceBlock(UniformInt.of(4, 9), props),
            p().mapColor(MapColor.COLOR_LIGHT_BLUE).strength(4.5f, 6f).sound(SoundType.DEEPSLATE).requiresCorrectToolForDrops().lightLevel(s -> 6));
    public static final Block VOIDITE_BLOCK = reg("voidite_block", Block::new,
            p().mapColor(MapColor.COLOR_PURPLE).strength(6f, 9f).sound(SoundType.METAL).requiresCorrectToolForDrops());
    public static final Block LUNARITE_BLOCK = reg("lunarite_block", Block::new,
            p().mapColor(MapColor.COLOR_LIGHT_BLUE).strength(6f, 9f).sound(SoundType.AMETHYST).requiresCorrectToolForDrops().lightLevel(s -> 8));
    public static final Block GLOW_CRYSTAL = reg("glow_crystal", Block::new,
            p().mapColor(MapColor.COLOR_MAGENTA).strength(1f).sound(SoundType.AMETHYST).lightLevel(s -> 15));

    // --- Portal ---
    public static final Block RUNED_OBSIDIAN = reg("runed_obsidian", Block::new,
            p().mapColor(MapColor.COLOR_BLACK).strength(35f, 1200f).sound(SoundType.STONE).requiresCorrectToolForDrops().lightLevel(s -> 4));
    public static final Block NYX_CORE_BLOCK = reg("nyx_core_block", Block::new,
            p().mapColor(MapColor.COLOR_MAGENTA).strength(45f, 1200f).sound(SoundType.METAL).requiresCorrectToolForDrops().lightLevel(s -> 10));
    public static final Block NYX_PORTAL = register("nyx_portal", NyxPortalBlock::new,
            p().noCollision().noOcclusion().strength(-1f).lightLevel(s -> 12).noLootTable(), false);

    private static Block reg(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties props) {
        return register(name, factory, props, true);
    }

    private static Block register(String name, Function<BlockBehaviour.Properties, Block> factory,
                                  BlockBehaviour.Properties props, boolean withItem) {
        ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, Nyxheim.id(name));
        Block block = Registry.register(BuiltInRegistries.BLOCK, key, factory.apply(props.setId(key)));
        if (withItem) {
            ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, Nyxheim.id(name));
            Registry.register(BuiltInRegistries.ITEM, itemKey,
                    new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix()));
        }
        return block;
    }

    public static void init() { }
}

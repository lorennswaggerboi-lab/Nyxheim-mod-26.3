package com.nyxheim.world;

import com.nyxheim.Nyxheim;
import com.nyxheim.registry.ModBlocks;
import com.nyxheim.registry.ModEntities;
import com.nyxheim.registry.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Post-procesa cada chunk NUEVO de la dimensión Nyxheim:
 *  1) terreno amplificado (enorme) con piedra/pasto/árboles tematizados,
 *  2) minerales propios (voidita y lunarita),
 *  3) espinas de cristal, y estructuras: Obelisco, Cripta y Anillo Antiguo.
 * Todo queda dentro del chunk para no depender de chunks vecinos.
 */
public final class NyxWorldgen {
    private NyxWorldgen() { }

    public static void init() {
        ServerChunkEvents.CHUNK_LOAD.register((level, chunk, generated) -> {
            if (!generated || !level.dimension().equals(Nyxheim.NYX)) return;
            try {
                process(level, chunk);
            } catch (Exception e) {
                Nyxheim.LOGGER.error("Error generando contenido de Nyxheim en {}", chunk.getPos(), e);
            }
        });
    }

    // ---------- Helpers de chunk (coordenadas locales 0..15) ----------

    private static BlockPos world(LevelChunk c, int x, int y, int z) {
        return new BlockPos(c.getPos().getMinBlockX() + x, y, c.getPos().getMinBlockZ() + z);
    }

    private static boolean inside(LevelChunk c, int x, int y, int z) {
        return x >= 0 && x < 16 && z >= 0 && z < 16 && y >= c.getMinY() && y < c.getMinY() + c.getHeight();
    }

    private static BlockState get(LevelChunk c, int x, int y, int z) {
        return c.getBlockState(world(c, x, y, z));
    }

    private static void set(LevelChunk c, int x, int y, int z, BlockState state) {
        if (!inside(c, x, y, z)) return;
        LevelChunkSection section = c.getSection(c.getSectionIndex(y));
        section.setBlockState(x, y & 15, z, state, false);
    }

    private static int surface(LevelChunk c, int x, int z) {
        return c.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z);
    }

    // ---------- Proceso principal ----------

    private static void process(ServerLevel level, LevelChunk chunk) {
        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        RandomSource rng = RandomSource.create(level.getSeed() ^ (minX * 341873128712L) ^ (minZ * 132897987541L));

        retheme(chunk);
        ores(chunk, rng);
        spires(level, chunk, rng);

        int roll = rng.nextInt(100);
        if (roll < 2) obelisk(level, chunk, rng);
        else if (roll < 4) crypt(level, chunk, rng);
        else if (roll < 5) ring(level, chunk, rng);
    }

    /** Cambia piedra/tierra/pasto/hojas/troncos vanilla por los bloques de Nyxheim. */
    private static void retheme(LevelChunk c) {
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int top = surface(c, x, z);
                for (int y = c.getMinY(); y < top; y++) {
                    BlockState s = get(c, x, y, z);
                    if (s.isAir()) continue;
                    if (s.is(Blocks.STONE) || s.is(Blocks.ANDESITE) || s.is(Blocks.DIORITE) || s.is(Blocks.GRANITE)
                            || s.is(Blocks.DEEPSLATE) || s.is(Blocks.TUFF)) {
                        set(c, x, y, z, ModBlocks.NYX_STONE.defaultBlockState());
                    } else if (s.is(Blocks.GRASS_BLOCK)) {
                        set(c, x, y, z, ModBlocks.NYX_GRASS_BLOCK.defaultBlockState());
                    } else if (s.is(Blocks.DIRT) || s.is(Blocks.COARSE_DIRT) || s.is(Blocks.PODZOL) || s.is(Blocks.MYCELIUM)) {
                        set(c, x, y, z, ModBlocks.NYX_DIRT.defaultBlockState());
                    }
                }
                int maxY = Math.min(top + 48, c.getMinY() + c.getHeight());
                for (int y = top; y < maxY; y++) {
                    BlockState s = get(c, x, y, z);
                    if (s.isAir()) continue;
                    if (s.is(BlockTags.LEAVES)) {
                        set(c, x, y, z, ModBlocks.NYX_LEAVES.defaultBlockState());
                    } else if (s.is(BlockTags.LOGS) && s.hasProperty(BlockStateProperties.AXIS)) {
                        set(c, x, y, z, ModBlocks.NYX_LOG.defaultBlockState()
                                .setValue(RotatedPillarBlock.AXIS, s.getValue(BlockStateProperties.AXIS)));
                    }
                }
            }
        }
    }

    private static void ores(LevelChunk c, RandomSource rng) {
        for (int i = 0; i < 7; i++) vein(c, rng, ModBlocks.VOIDITE_ORE.defaultBlockState(), -60, 40, 4 + rng.nextInt(5));
        for (int i = 0; i < 4; i++) vein(c, rng, ModBlocks.LUNARITE_ORE.defaultBlockState(), -50, 30, 3 + rng.nextInt(4));
    }

    private static void vein(LevelChunk c, RandomSource rng, BlockState ore, int minY, int maxY, int size) {
        int x = rng.nextInt(16), z = rng.nextInt(16), y = minY + rng.nextInt(maxY - minY + 1);
        for (int k = 0; k < size; k++) {
            if (inside(c, x, y, z) && get(c, x, y, z).is(ModBlocks.NYX_STONE)) set(c, x, y, z, ore);
            x += rng.nextInt(3) - 1;
            y += rng.nextInt(3) - 1;
            z += rng.nextInt(3) - 1;
        }
    }

    private static void spires(ServerLevel level, LevelChunk c, RandomSource rng) {
        if (rng.nextInt(3) != 0) return;
        int x = 2 + rng.nextInt(12), z = 2 + rng.nextInt(12);
        int top = surface(c, x, z);
        if (top <= level.getSeaLevel() || !get(c, x, top - 1, z).is(ModBlocks.NYX_GRASS_BLOCK)) return;
        int h = 4 + rng.nextInt(6);
        for (int y = 0; y < h; y++) set(c, x, top + y, z, ModBlocks.GLOW_CRYSTAL.defaultBlockState());
        for (Direction d : Direction.Plane.HORIZONTAL) {
            for (int y = 0; y < h / 2; y++) set(c, x + d.getStepX(), top + y, z + d.getStepZ(), ModBlocks.GLOW_CRYSTAL.defaultBlockState());
        }
    }

    // ---------- Estructuras ----------

    private static void fillBox(LevelChunk c, int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        for (int x = x1; x <= x2; x++) for (int y = y1; y <= y2; y++) for (int z = z1; z <= z2; z++) set(c, x, y, z, s);
    }

    private static void chest(LevelChunk c, int x, int y, int z, Direction facing, RandomSource rng, boolean rich) {
        BlockPos pos = world(c, x, y, z);
        BlockState state = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, facing);
        set(c, x, y, z, state);
        ChestBlockEntity be = new ChestBlockEntity(pos, state);
        Item[] common = {ModItems.RAW_VOIDITE, ModItems.LUNARITE_SHARD, Items.IRON_INGOT, Items.GOLD_INGOT, ModItems.NYX_APPLE, Items.ENDER_PEARL};
        Item[] rare = {ModItems.VOIDITE_INGOT, Items.DIAMOND, Items.GOLDEN_APPLE, Items.ECHO_SHARD, Items.NETHERITE_SCRAP};
        int n = rich ? 10 : 5;
        for (int i = 0; i < n; i++) {
            Item it = (rich && rng.nextInt(3) == 0) ? rare[rng.nextInt(rare.length)] : common[rng.nextInt(common.length)];
            be.setItem(rng.nextInt(27), new ItemStack(it, 1 + rng.nextInt(3)));
        }
        c.setBlockEntity(be);
    }

    /** Obelisco: torre de ladrillos con cristales y cofre al pie. */
    private static void obelisk(ServerLevel level, LevelChunk c, RandomSource rng) {
        int y = surface(c, 8, 8);
        if (y <= level.getSeaLevel()) return;
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState bricks = ModBlocks.NYX_BRICKS.defaultBlockState();
        fillBox(c, 5, y, 5, 11, y + 14, 11, air);
        fillBox(c, 5, y - 1, 5, 11, y - 1, 11, bricks);
        fillBox(c, 7, y, 7, 9, y + 3, 9, bricks);
        fillBox(c, 8, y + 4, 8, 8, y + 12, 8, bricks);
        set(c, 8, y + 13, 8, ModBlocks.GLOW_CRYSTAL.defaultBlockState());
        for (Direction d : Direction.Plane.HORIZONTAL) {
            set(c, 8 + d.getStepX(), y + 11, 8 + d.getStepZ(), ModBlocks.GLOW_CRYSTAL.defaultBlockState());
        }
        chest(c, 8, y, 6, Direction.NORTH, rng, false);
    }

    /** Cripta subterránea con escalera, spawner de espectros y 2 cofres ricos. */
    private static void crypt(ServerLevel level, LevelChunk c, RandomSource rng) {
        int top = surface(c, 8, 8);
        if (top <= level.getSeaLevel() + 2) return;
        int y0 = Math.max(c.getMinY() + 6, top - 16);
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState bricks = ModBlocks.NYX_BRICKS.defaultBlockState();
        // pozo con escalera
        fillBox(c, 7, y0, 7, 9, top + 1, 9, bricks);
        fillBox(c, 8, y0, 8, 8, top + 1, 8, air);
        for (int y = y0 + 1; y <= top; y++) {
            set(c, 8, y, 8, Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.SOUTH));
            set(c, 8, y, 7, bricks);
        }
        // sala
        fillBox(c, 2, y0 - 1, 2, 13, y0 + 5, 13, bricks);
        fillBox(c, 3, y0, 3, 12, y0 + 4, 12, air);
        fillBox(c, 7, y0 + 5, 7, 9, y0 + 5, 9, bricks);
        set(c, 8, y0 + 5, 8, air);
        set(c, 8, y0 + 5, 7, bricks);
        set(c, 8, y0, 7, bricks);
        set(c, 8, y0 + 1, 7, bricks);
        for (int cx : new int[]{3, 12}) for (int cz : new int[]{3, 12}) set(c, cx, y0, cz, ModBlocks.GLOW_CRYSTAL.defaultBlockState());
        // spawner
        BlockPos sp = world(c, 8, y0, 11);
        BlockState sState = Blocks.SPAWNER.defaultBlockState();
        set(c, 8, y0, 11, sState);
        SpawnerBlockEntity sbe = new SpawnerBlockEntity(sp, sState);
        sbe.setEntityId(ModEntities.NYX_WRAITH, rng);
        c.setBlockEntity(sbe);
        chest(c, 4, y0, 12, Direction.SOUTH, rng, true);
        chest(c, 11, y0, 12, Direction.SOUTH, rng, true);
    }

    /** Anillo antiguo: 8 pilares alrededor de un altar de obsidiana rúnica con cofre. */
    private static void ring(ServerLevel level, LevelChunk c, RandomSource rng) {
        int y = surface(c, 8, 8);
        if (y <= level.getSeaLevel()) return;
        BlockState bricks = ModBlocks.NYX_BRICKS.defaultBlockState();
        fillBox(c, 1, y, 1, 14, y + 8, 14, Blocks.AIR.defaultBlockState());
        fillBox(c, 1, y - 1, 1, 14, y - 1, 14, ModBlocks.NYX_STONE.defaultBlockState());
        int[][] spots = {{2, 2}, {7, 1}, {13, 2}, {14, 7}, {13, 13}, {7, 14}, {2, 13}, {1, 7}};
        for (int[] s : spots) {
            int h = 4 + rng.nextInt(4);
            fillBox(c, s[0], y, s[1], s[0], y + h, s[1], bricks);
            set(c, s[0], y + h + 1, s[1], ModBlocks.GLOW_CRYSTAL.defaultBlockState());
        }
        fillBox(c, 7, y, 7, 9, y, 9, ModBlocks.RUNED_OBSIDIAN.defaultBlockState());
        chest(c, 8, y + 1, 8, Direction.NORTH, rng, true);
    }
}

package com.nyxheim.entity;

import com.nyxheim.registry.ModEntities;
import com.nyxheim.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Jefe: enorme, con barra de vida, invoca espectros y lanza ondas de choque. */
public class NyxColossus extends Zombie {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.nyxheim.nyx_colossus"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);

    public NyxColossus(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
        this.xpReward = 120;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 400.0)
                .add(Attributes.ATTACK_DAMAGE, 14.0)
                .add(Attributes.MOVEMENT_SPEED, 0.27)
                .add(Attributes.ARMOR, 10.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.SCALE, 2.2)
                .add(Attributes.SPAWN_REINFORCEMENTS_CHANCE, 0.0);
    }

    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    @Override
    public boolean isBaby() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distanceSquared) {
        return false;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    protected void customServerAiStep(ServerLevel level) {
        super.customServerAiStep(level);
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
        if (this.getTarget() == null) return;

        // Onda de choque cada 5 s
        if (this.tickCount % 100 == 0) {
            for (Player p : level.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(7.0))) {
                p.hurtServer(level, this.damageSources().mobAttack(this), 8.0f);
                p.knockback(1.6, this.getX() - p.getX(), this.getZ() - p.getZ());
            }
        }
        // Invoca 2 espectros cada 12 s (máx. 6 cerca)
        if (this.tickCount % 240 == 0) {
            int near = level.getEntitiesOfClass(NyxWraith.class, this.getBoundingBox().inflate(24.0)).size();
            if (near < 6) {
                for (int i = 0; i < 2; i++) {
                    ModEntities.NYX_WRAITH.spawn(level,
                            this.blockPosition().offset(this.random.nextInt(7) - 3, 0, this.random.nextInt(7) - 3),
                            EntitySpawnReason.MOB_SUMMONED);
                }
            }
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (this.level() instanceof ServerLevel sl) {
            this.spawnAtLocation(sl, new ItemStack(ModItems.VOIDITE_INGOT, 8 + this.random.nextInt(9)));
            this.spawnAtLocation(sl, new ItemStack(ModItems.LUNARITE_SHARD, 8 + this.random.nextInt(7)));
            this.spawnAtLocation(sl, new ItemStack(ModItems.NYX_APPLE, 3));
        }
    }
}

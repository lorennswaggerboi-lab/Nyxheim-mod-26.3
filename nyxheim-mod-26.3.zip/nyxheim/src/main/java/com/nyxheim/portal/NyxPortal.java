package com.nyxheim.portal;

import com.nyxheim.Nyxheim;
import com.nyxheim.block.NyxPortalBlock;
import com.nyxheim.registry.ModBlocks;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.portal.TeleportTransition;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Portal de Nyxheim.
 * Marco de 6 x 7 bloques: 4 esquinas de Núcleo de Nyx + 18 bloques de Obsidiana Rúnica,
 * interior de 4 x 5 libre. Se enciende con el Ojo de Nyx.
 */
public final class NyxPortal {
    public static final int W = 6;
    public static final int H = 7;
    private static final int CHARGE_TICKS = 80;
    private static final Map<UUID, Integer> TIMERS = new HashMap<>();

    private NyxPortal() { }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(NyxPortal::tick);
    }

    // ---------- Activación ----------

    private static BlockPos cell(BlockPos origin, Direction.Axis axis, int i, int j) {
        return axis == Direction.Axis.X ? origin.offset(i, j, 0) : origin.offset(0, j, i);
    }

    public static boolean tryActivate(Level level, BlockPos clicked) {
        for (Direction.Axis axis : new Direction.Axis[]{Direction.Axis.X, Direction.Axis.Z}) {
            for (int i = 0; i < W; i++) {
                for (int j = 0; j < H; j++) {
                    BlockPos origin = axis == Direction.Axis.X ? clicked.offset(-i, -j, 0) : clicked.offset(0, -j, -i);
                    if (isFrame(level, origin, axis)) {
                        fillPortal(level, origin, axis);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static boolean isFrame(Level level, BlockPos origin, Direction.Axis axis) {
        for (int i = 0; i < W; i++) {
            for (int j = 0; j < H; j++) {
                BlockState s = level.getBlockState(cell(origin, axis, i, j));
                boolean border = i == 0 || i == W - 1 || j == 0 || j == H - 1;
                if (border) {
                    boolean corner = (i == 0 || i == W - 1) && (j == 0 || j == H - 1);
                    if (!s.is(corner ? ModBlocks.NYX_CORE_BLOCK : ModBlocks.RUNED_OBSIDIAN)) return false;
                } else if (!s.isAir() && !s.is(ModBlocks.NYX_PORTAL)) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void fillPortal(Level level, BlockPos origin, Direction.Axis axis) {
        BlockState portal = ModBlocks.NYX_PORTAL.defaultBlockState().setValue(NyxPortalBlock.AXIS, axis);
        for (int i = 1; i < W - 1; i++) {
            for (int j = 1; j < H - 1; j++) {
                level.setBlock(cell(origin, axis, i, j), portal, Block.UPDATE_ALL);
            }
        }
    }

    // ---------- Teletransporte ----------

    private static void tick(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            ServerLevel level = (ServerLevel) p.level();
            BlockPos feet = p.blockPosition();
            boolean inside = level.getBlockState(feet).is(ModBlocks.NYX_PORTAL)
                    || level.getBlockState(feet.above()).is(ModBlocks.NYX_PORTAL);
            UUID id = p.getUUID();
            if (!inside) {
                TIMERS.remove(id);
                continue;
            }
            int t = TIMERS.merge(id, 1, Integer::sum);
            if (t >= CHARGE_TICKS) {
                TIMERS.remove(id);
                teleport(p, level);
            }
        }
    }

    private static void teleport(ServerPlayer player, ServerLevel from) {
        MinecraftServer server = from.getServer();
        boolean toNyx = !from.dimension().equals(Nyxheim.NYX);
        ServerLevel dest = toNyx ? server.getLevel(Nyxheim.NYX) : server.overworld();
        if (dest == null) {
            player.sendSystemMessage(Component.translatable("message.nyxheim.no_dimension"));
            return;
        }
        int x = player.blockPosition().getX();
        int z = player.blockPosition().getZ();
        dest.getChunk(x >> 4, z >> 4); // fuerza la carga del chunk de destino

        Arrival arrival = findExistingGate(dest, x, z);
        if (arrival == null) {
            int ground = Math.max(dest.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), dest.getSeaLevel() + 1);
            BlockPos origin = new BlockPos(x - W / 2, ground - 1, z);
            buildGate(dest, origin);
            arrival = new Arrival(new Vec3(origin.getX() + W / 2.0, ground, origin.getZ() + 2.5), 180f);
        }
        player.teleport(new TeleportTransition(dest, arrival.pos, Vec3.ZERO, arrival.yaw, 0f, TeleportTransition.DO_NOTHING));
    }

    private record Arrival(Vec3 pos, float yaw) { }

    /** Busca un portal ya construido cerca de x,z para reutilizarlo. */
    private static Arrival findExistingGate(ServerLevel level, int x, int z) {
        int h = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -12; dx <= 12; dx++) {
            for (int dz = -12; dz <= 12; dz++) {
                for (int y = h - 8; y <= h + 12; y++) {
                    m.set(x + dx, y, z + dz);
                    BlockState s = level.getBlockState(m);
                    if (s.is(ModBlocks.NYX_PORTAL)) {
                        Direction.Axis axis = s.getValue(NyxPortalBlock.AXIS);
                        // baja hasta el borde inferior del interior
                        BlockPos.MutableBlockPos b = m.mutable();
                        while (level.getBlockState(b.below()).is(ModBlocks.NYX_PORTAL)) b.move(Direction.DOWN);
                        Vec3 pos = axis == Direction.Axis.X
                                ? new Vec3(b.getX() + 0.5, b.getY(), b.getZ() + 2.5)
                                : new Vec3(b.getX() + 2.5, b.getY(), b.getZ() + 0.5);
                        return new Arrival(pos, axis == Direction.Axis.X ? 180f : 90f);
                    }
                }
            }
        }
        return null;
    }

    /** Construye una puerta (eje X) con plataforma y despeja el espacio. */
    private static void buildGate(ServerLevel level, BlockPos origin) {
        BlockState air = Blocks.AIR.defaultBlockState();
        // despeje y plataforma
        for (int i = -2; i <= W + 1; i++) {
            for (int k = -3; k <= 3; k++) {
                level.setBlock(origin.offset(i, 0, k), ModBlocks.NYX_BRICKS.defaultBlockState(), Block.UPDATE_CLIENTS);
                for (int j = 1; j <= H + 2; j++) {
                    level.setBlock(origin.offset(i, j, k), air, Block.UPDATE_CLIENTS);
                }
            }
        }
        for (int i = 0; i < W; i++) {
            for (int j = 0; j < H; j++) {
                boolean border = i == 0 || i == W - 1 || j == 0 || j == H - 1;
                if (!border) continue;
                boolean corner = (i == 0 || i == W - 1) && (j == 0 || j == H - 1);
                level.setBlock(origin.offset(i, j, 0),
                        (corner ? ModBlocks.NYX_CORE_BLOCK : ModBlocks.RUNED_OBSIDIAN).defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        fillPortal(level, origin, Direction.Axis.X);
    }
}

#!/usr/bin/env python3
"""Genera texturas, modelos, blockstates, lang, recetas, loot tables, tags y la dimensión."""
import json, os, random
from PIL import Image, ImageDraw

R = "src/main/resources"
A = f"{R}/assets/nyxheim"
D = f"{R}/data/nyxheim"
M = "nyxheim"

def w(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        if isinstance(data, str): f.write(data)
        else: json.dump(data, f, indent=2, ensure_ascii=False)

def clamp(v): return max(0, min(255, int(v)))

def noise_tex(base, var=14, seed=0, size=16):
    rnd = random.Random(seed)
    im = Image.new("RGBA", (size, size))
    for x in range(size):
        for y in range(size):
            d = rnd.randint(-var, var)
            im.putpixel((x, y), (clamp(base[0]+d), clamp(base[1]+d), clamp(base[2]+d), 255))
    return im

def save_block(name, im):
    os.makedirs(f"{A}/textures/block", exist_ok=True); im.save(f"{A}/textures/block/{name}.png")

def save_item(name, im):
    os.makedirs(f"{A}/textures/item", exist_ok=True); im.save(f"{A}/textures/item/{name}.png")

# ---------------- BLOQUES ----------------
simple = {
    "nyx_stone": (44, 38, 62), "nyx_bricks": (58, 50, 84), "nyx_dirt": (66, 46, 78),
    "nyx_planks": (96, 58, 130), "nyx_leaves": (150, 50, 190),
    "voidite_block": (100, 40, 190), "lunarite_block": (140, 215, 240),
    "glow_crystal": (200, 120, 255), "runed_obsidian": (22, 12, 36), "nyx_core_block": (190, 60, 210),
}
for i, (n, c) in enumerate(simple.items()):
    im = noise_tex(c, 16, i)
    if n == "nyx_bricks":
        d = ImageDraw.Draw(im)
        for y in (0, 5, 10, 15): d.line([(0, y), (15, y)], fill=(25, 20, 40, 255))
        for x in (3, 11): d.line([(x, 0), (x, 4)], fill=(25, 20, 40, 255)); d.line([(x+4 if x < 8 else x-5, 5), (x+4 if x < 8 else x-5, 9)], fill=(25, 20, 40, 255))
    if n in ("runed_obsidian", "nyx_core_block"):
        d = ImageDraw.Draw(im); col = (170, 90, 255, 255) if n == "runed_obsidian" else (255, 220, 255, 255)
        d.rectangle([2, 2, 13, 13], outline=col)
        d.line([(5, 8), (10, 8)], fill=col); d.line([(8, 5), (8, 10)], fill=col)
    if n == "glow_crystal":
        d = ImageDraw.Draw(im)
        for (x, y) in [(3, 3), (9, 5), (5, 11), (12, 12)]: d.rectangle([x, y, x+1, y+1], fill=(255, 230, 255, 255))
    save_block(n, im)

for n, spots in (("voidite_ore", (150, 60, 255)), ("lunarite_ore", (120, 230, 255))):
    im = noise_tex((44, 38, 62), 12, 99 + len(n))
    rnd = random.Random(len(n)); d = ImageDraw.Draw(im)
    for _ in range(7):
        x, y = rnd.randint(1, 13), rnd.randint(1, 13); d.rectangle([x, y, x+1, y+1], fill=spots + (255,))
    save_block(n, im)

top = noise_tex((140, 70, 200), 18, 5); save_block("nyx_grass_top", top)
side = noise_tex((66, 46, 78), 14, 6); ds = ImageDraw.Draw(side)
for x in range(16):
    for y in range(4 + (x * 7) % 3):
        side.putpixel((x, y), top.getpixel((x, y)))
save_block("nyx_grass_side", side)
log_side = noise_tex((70, 40, 100), 10, 7); dl = ImageDraw.Draw(log_side)
for x in (2, 6, 10, 14): dl.line([(x, 0), (x, 15)], fill=(40, 22, 60, 255))
save_block("nyx_log", log_side)
log_top = noise_tex((120, 80, 160), 10, 8); ImageDraw.Draw(log_top).rectangle([2, 2, 13, 13], outline=(70, 40, 100, 255)); save_block("nyx_log_top", log_top)

# portal: espiral violeta
pi = Image.new("RGBA", (16, 16))
import math
for x in range(16):
    for y in range(16):
        a = math.atan2(y-7.5, x-7.5); r = math.hypot(x-7.5, y-7.5)
        v = (math.sin(a*3 + r*0.9) + 1) / 2
        pi.putpixel((x, y), (clamp(60+140*v), clamp(10+60*v), clamp(120+135*v), 255))
save_block("nyx_portal", pi)

# modelos / blockstates / items de bloques
cube = ["nyx_stone","nyx_bricks","nyx_dirt","nyx_planks","nyx_leaves","voidite_ore","lunarite_ore",
        "voidite_block","lunarite_block","glow_crystal","runed_obsidian","nyx_core_block"]
for n in cube:
    w(f"{A}/models/block/{n}.json", {"parent": "minecraft:block/cube_all", "textures": {"all": f"{M}:block/{n}"}})
    w(f"{A}/blockstates/{n}.json", {"variants": {"": {"model": f"{M}:block/{n}"}}})
    w(f"{A}/items/{n}.json", {"model": {"type": "minecraft:model", "model": f"{M}:block/{n}"}})
w(f"{A}/models/block/nyx_grass_block.json", {"parent": "minecraft:block/cube_bottom_top",
  "textures": {"top": f"{M}:block/nyx_grass_top", "side": f"{M}:block/nyx_grass_side", "bottom": f"{M}:block/nyx_dirt"}})
w(f"{A}/blockstates/nyx_grass_block.json", {"variants": {"": {"model": f"{M}:block/nyx_grass_block"}}})
w(f"{A}/items/nyx_grass_block.json", {"model": {"type": "minecraft:model", "model": f"{M}:block/nyx_grass_block"}})
w(f"{A}/models/block/nyx_log.json", {"parent": "minecraft:block/cube_column",
  "textures": {"end": f"{M}:block/nyx_log_top", "side": f"{M}:block/nyx_log"}})
w(f"{A}/blockstates/nyx_log.json", {"variants": {"axis=y": {"model": f"{M}:block/nyx_log"},
  "axis=z": {"model": f"{M}:block/nyx_log", "x": 90}, "axis=x": {"model": f"{M}:block/nyx_log", "x": 90, "y": 90}}})
w(f"{A}/items/nyx_log.json", {"model": {"type": "minecraft:model", "model": f"{M}:block/nyx_log"}})
face = {"texture": "#p", "uv": [0, 0, 16, 16]}
w(f"{A}/models/block/nyx_portal.json", {"textures": {"particle": f"{M}:block/nyx_portal", "p": f"{M}:block/nyx_portal"},
  "elements": [{"from": [0, 0, 7], "to": [16, 16, 9], "faces": {"north": face, "south": dict(face, cullface=None) if False else face}}]})
w(f"{A}/blockstates/nyx_portal.json", {"variants": {"axis=x": {"model": f"{M}:block/nyx_portal"},
  "axis=z": {"model": f"{M}:block/nyx_portal", "y": 90}}})

# ---------------- ITEMS ----------------
def item_im(draw_fn):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); draw_fn(ImageDraw.Draw(im)); return im
def ingot(c1, c2):
    def f(d):
        d.polygon([(2, 9), (9, 3), (14, 6), (7, 12)], fill=c1); d.polygon([(2, 9), (7, 12), (7, 14), (2, 11)], fill=c2); d.polygon([(7, 12), (14, 6), (14, 8), (7, 14)], fill=c2)
    return f
def shard(c1, c2):
    def f(d):
        d.polygon([(8, 1), (12, 8), (8, 15), (4, 8)], fill=c1); d.polygon([(8, 1), (12, 8), (8, 8)], fill=c2)
    return f
def raw(c1, c2):
    def f(d):
        d.ellipse([3, 4, 13, 13], fill=c1); d.ellipse([5, 6, 8, 9], fill=c2); d.ellipse([9, 9, 11, 11], fill=c2)
    return f
def eye(d):
    d.ellipse([2, 2, 13, 13], fill=(30, 10, 60, 255), outline=(190, 90, 255, 255)); d.ellipse([5, 5, 10, 10], fill=(255, 120, 255, 255)); d.rectangle([7, 6, 8, 9], fill=(20, 0, 30, 255))
def sigil(d):
    d.polygon([(8, 1), (10, 6), (15, 6), (11, 9), (13, 14), (8, 11), (3, 14), (5, 9), (1, 6), (6, 6)], fill=(170, 60, 255, 255), outline=(255, 200, 255, 255))
def apple(d):
    d.ellipse([3, 4, 13, 14], fill=(150, 40, 220, 255)); d.ellipse([5, 5, 7, 7], fill=(230, 160, 255, 255)); d.line([(8, 2), (9, 4)], fill=(90, 220, 140, 255))
def sword(d):
    d.line([(3, 13), (12, 4)], fill=(150, 70, 240, 255), width=2); d.line([(12, 4), (14, 2)], fill=(230, 190, 255, 255), width=2)
    d.line([(3, 9), (7, 13)], fill=(60, 40, 90, 255), width=2); d.line([(1, 15), (3, 13)], fill=(100, 60, 30, 255), width=2)
def pick(d):
    d.line([(3, 13), (11, 5)], fill=(110, 70, 40, 255), width=2); d.arc([2, 0, 15, 12], 200, 340, fill=(150, 70, 240, 255), width=3)
items = {"raw_voidite": raw((110, 50, 190, 255), (180, 110, 255, 255)), "voidite_ingot": ingot((140, 70, 230, 255), (80, 30, 150, 255)),
         "lunarite_shard": shard((130, 225, 250, 255), (230, 255, 255, 255)), "eye_of_nyx": eye, "nyx_sigil": sigil,
         "nyx_apple": apple, "voidite_sword": sword, "voidite_pickaxe": pick}
for n, fn in items.items():
    save_item(n, item_im(fn))
    parent = "minecraft:item/handheld" if n in ("voidite_sword", "voidite_pickaxe") else "minecraft:item/generated"
    w(f"{A}/models/item/{n}.json", {"parent": parent, "textures": {"layer0": f"{M}:item/{n}"}})
    w(f"{A}/items/{n}.json", {"model": {"type": "minecraft:model", "model": f"{M}:item/{n}"}})

# ---------------- ENTIDADES (piel 64x64 de zombi) ----------------
def skin(name, base, eyes, seed):
    im = noise_tex(base, 14, seed, 64); d = ImageDraw.Draw(im)
    for ex in (9, 13): d.rectangle([ex, 11, ex+1, 12], fill=eyes + (255,))
    d.rectangle([10, 14, 13, 14], fill=(15, 5, 25, 255))
    os.makedirs(f"{A}/textures/entity", exist_ok=True); im.save(f"{A}/textures/entity/{name}.png")
skin("nyx_wraith", (46, 30, 82), (255, 80, 255), 1)
skin("crystal_brute", (70, 120, 150), (255, 255, 160), 2)
skin("nyx_colossus", (28, 10, 40), (255, 60, 60), 3)

# ---------------- LANG ----------------
es = {
 "block.nyxheim.nyx_stone": "Piedra de Nyx", "block.nyxheim.nyx_bricks": "Ladrillos de Nyx",
 "block.nyxheim.nyx_dirt": "Tierra de Nyx", "block.nyxheim.nyx_grass_block": "Césped de Nyx",
 "block.nyxheim.nyx_log": "Tronco de Nyx", "block.nyxheim.nyx_planks": "Tablones de Nyx",
 "block.nyxheim.nyx_leaves": "Hojas de Nyx", "block.nyxheim.voidite_ore": "Mena de voidita",
 "block.nyxheim.lunarite_ore": "Mena de lunarita", "block.nyxheim.voidite_block": "Bloque de voidita",
 "block.nyxheim.lunarite_block": "Bloque de lunarita", "block.nyxheim.glow_crystal": "Cristal luminoso",
 "block.nyxheim.runed_obsidian": "Obsidiana rúnica", "block.nyxheim.nyx_core_block": "Núcleo de Nyx",
 "block.nyxheim.nyx_portal": "Portal de Nyx",
 "item.nyxheim.raw_voidite": "Voidita en bruto", "item.nyxheim.voidite_ingot": "Lingote de voidita",
 "item.nyxheim.lunarite_shard": "Fragmento de lunarita", "item.nyxheim.eye_of_nyx": "Ojo de Nyx",
 "item.nyxheim.nyx_sigil": "Sigilo de Nyx", "item.nyxheim.nyx_apple": "Manzana de Nyx",
 "item.nyxheim.voidite_sword": "Espada de voidita", "item.nyxheim.voidite_pickaxe": "Pico de voidita",
 "entity.nyxheim.nyx_wraith": "Espectro de Nyx", "entity.nyxheim.crystal_brute": "Bruto de cristal",
 "entity.nyxheim.nyx_colossus": "Coloso de Nyx",
 "message.nyxheim.bad_frame": "El marco no está completo: 6x7, 4 Núcleos en las esquinas y Obsidiana Rúnica en el resto.",
 "message.nyxheim.no_dimension": "La dimensión Nyxheim no se cargó. Revisá el log.",
 "message.nyxheim.sigil_wrong_dim": "El Sigilo solo responde dentro de Nyxheim.",
}
en = dict(es)
en.update({k: v for k, v in {
 "block.nyxheim.nyx_stone": "Nyx Stone", "block.nyxheim.nyx_bricks": "Nyx Bricks", "block.nyxheim.nyx_dirt": "Nyx Dirt",
 "block.nyxheim.nyx_grass_block": "Nyx Grass Block", "block.nyxheim.nyx_log": "Nyx Log", "block.nyxheim.nyx_planks": "Nyx Planks",
 "block.nyxheim.nyx_leaves": "Nyx Leaves", "block.nyxheim.voidite_ore": "Voidite Ore", "block.nyxheim.lunarite_ore": "Lunarite Ore",
 "block.nyxheim.voidite_block": "Block of Voidite", "block.nyxheim.lunarite_block": "Block of Lunarite",
 "block.nyxheim.glow_crystal": "Glow Crystal", "block.nyxheim.runed_obsidian": "Runed Obsidian", "block.nyxheim.nyx_core_block": "Nyx Core",
 "block.nyxheim.nyx_portal": "Nyx Portal", "item.nyxheim.raw_voidite": "Raw Voidite", "item.nyxheim.voidite_ingot": "Voidite Ingot",
 "item.nyxheim.lunarite_shard": "Lunarite Shard", "item.nyxheim.eye_of_nyx": "Eye of Nyx", "item.nyxheim.nyx_sigil": "Nyx Sigil",
 "item.nyxheim.nyx_apple": "Nyx Apple", "item.nyxheim.voidite_sword": "Voidite Sword", "item.nyxheim.voidite_pickaxe": "Voidite Pickaxe",
 "entity.nyxheim.nyx_wraith": "Nyx Wraith", "entity.nyxheim.crystal_brute": "Crystal Brute", "entity.nyxheim.nyx_colossus": "Nyx Colossus",
 "message.nyxheim.bad_frame": "The frame is incomplete: 6x7, 4 Nyx Cores in the corners and Runed Obsidian elsewhere.",
 "message.nyxheim.no_dimension": "The Nyxheim dimension did not load. Check the log.",
 "message.nyxheim.sigil_wrong_dim": "The Sigil only works inside Nyxheim."}.items()})
w(f"{A}/lang/es_es.json", es); w(f"{A}/lang/es_ar.json", es); w(f"{A}/lang/en_us.json", en)

# ---------------- LOOT TABLES ----------------
def self_drop(n):
    return {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{M}:{n}"}],
            "conditions": [{"condition": "minecraft:survives_explosion"}]}]}
def ore_drop(item, lo, hi):
    return {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{M}:{item}",
        "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}},
                      {"function": "minecraft:apply_bonus", "enchantment": "minecraft:fortune", "formula": "minecraft:ore_drops"}]}],
        "conditions": [{"condition": "minecraft:survives_explosion"}]}]}
for n in cube + ["nyx_grass_block", "nyx_log"]:
    if n in ("voidite_ore", "lunarite_ore"): continue
    w(f"{D}/loot_table/blocks/{n}.json", self_drop(n))
w(f"{D}/loot_table/blocks/voidite_ore.json", ore_drop("raw_voidite", 1, 2))
w(f"{D}/loot_table/blocks/lunarite_ore.json", ore_drop("lunarite_shard", 1, 3))

# ---------------- RECETAS ----------------
def shaped(name, pattern, key, result, count=1):
    w(f"{D}/recipe/{name}.json", {"type": "minecraft:crafting_shaped", "category": "misc", "pattern": pattern, "key": key,
                                   "result": {"id": result, "count": count}})
def shapeless(name, ings, result, count=1):
    w(f"{D}/recipe/{name}.json", {"type": "minecraft:crafting_shapeless", "category": "misc", "ingredients": ings,
                                   "result": {"id": result, "count": count}})
def cook(name, kind, ing, result, t):
    w(f"{D}/recipe/{name}.json", {"type": f"minecraft:{kind}", "category": "misc", "ingredient": ing,
                                   "result": {"id": result}, "experience": 1.0, "cookingtime": t})
V, L = f"{M}:voidite_ingot", f"{M}:lunarite_shard"
# Portal: receta muy cara a propósito
shaped("runed_obsidian", ["COC", "OEO", "COC"], {"C": "minecraft:crying_obsidian", "O": "minecraft:obsidian", "E": "minecraft:echo_shard"}, f"{M}:runed_obsidian", 2)
shaped("nyx_core_block", ["NDN", "DTD", "NDN"], {"N": "minecraft:netherite_ingot", "D": "minecraft:diamond_block", "T": "minecraft:totem_of_undying"}, f"{M}:nyx_core_block")
shapeless("eye_of_nyx", ["minecraft:nether_star", "minecraft:dragon_breath", "minecraft:heart_of_the_sea", "minecraft:echo_shard", "minecraft:netherite_ingot"], f"{M}:eye_of_nyx")
shaped("nyx_sigil", ["LVL", "VNV", "LVL"], {"L": L, "V": V, "N": "minecraft:nether_star"}, f"{M}:nyx_sigil")
shapeless("nyx_planks", [f"{M}:nyx_log"], f"{M}:nyx_planks", 4)
cook("voidite_ingot_smelting", "smelting", f"{M}:raw_voidite", V, 200)
cook("voidite_ingot_blasting", "blasting", f"{M}:raw_voidite", V, 100)
shaped("voidite_block", ["VVV", "VVV", "VVV"], {"V": V}, f"{M}:voidite_block")
shapeless("voidite_ingot_from_block", [f"{M}:voidite_block"], V, 9)
shaped("lunarite_block", ["LLL", "LLL", "LLL"], {"L": L}, f"{M}:lunarite_block")
shapeless("lunarite_from_block", [f"{M}:lunarite_block"], L, 9)
shaped("glow_crystal", ["LL", "LL"], {"L": L}, f"{M}:glow_crystal", 2)
shaped("nyx_bricks", ["SS", "SS"], {"S": f"{M}:nyx_stone"}, f"{M}:nyx_bricks", 4)
shaped("voidite_sword", ["V", "V", "S"], {"V": V, "S": "minecraft:stick"}, f"{M}:voidite_sword")
shaped("voidite_pickaxe", ["VVV", " S ", " S "], {"V": V, "S": "minecraft:stick"}, f"{M}:voidite_pickaxe")
shaped("nyx_apple", ["LLL", "LAL", "LLL"], {"L": L, "A": "minecraft:golden_apple"}, f"{M}:nyx_apple")

# ---------------- TAGS ----------------
def tag(path, values): w(path, {"values": values})
b = lambda *n: [f"{M}:{x}" for x in n]
tag(f"{R}/data/minecraft/tags/block/mineable/pickaxe.json", b("nyx_stone","nyx_bricks","voidite_ore","lunarite_ore","voidite_block","lunarite_block","runed_obsidian","nyx_core_block","glow_crystal"))
tag(f"{R}/data/minecraft/tags/block/mineable/shovel.json", b("nyx_dirt","nyx_grass_block"))
tag(f"{R}/data/minecraft/tags/block/mineable/axe.json", b("nyx_log","nyx_planks"))
tag(f"{R}/data/minecraft/tags/block/mineable/hoe.json", b("nyx_leaves"))
tag(f"{R}/data/minecraft/tags/block/needs_iron_tool.json", b("voidite_ore","lunarite_ore","voidite_block","lunarite_block"))
tag(f"{R}/data/minecraft/tags/block/needs_diamond_tool.json", b("runed_obsidian","nyx_core_block"))
tag(f"{D}/tags/item/voidite_repair.json", [V])

# ---------------- DIMENSIÓN ----------------
w(f"{D}/dimension/nyx.json", {
  "type": "minecraft:overworld",
  "generator": {"type": "minecraft:noise", "settings": "minecraft:amplified",
                "biome_source": {"type": "minecraft:multi_noise", "preset": "minecraft:overworld"}}})
print("assets ok")

package com.nyxheim.world;

import com.nyxheim.Nyxheim;
import com.nyxheim.entity.CrystalBrute;
import com.nyxheim.entity.NyxWraith;
import com.nyxheim.registry.ModEntities;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

/** Spawner propio: genera enemigos de Nyxheim cerca de los jugadores, de día y de noche. */
public final class NyxSpawner {
    private NyxSpawner() { }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 40 != 0) return;
            ServerLevel nyx = server.getLevel(Nyxheim.NYX);
            if (nyx == null) return;
            RandomSource r = nyx.getRandom();
            for (ServerPlayer p : nyx.players()) {
                int near = nyx.getEntitiesOfClass(Zombie.class, new AABB(p.blockPosition()).inflate(48),
                        z -> z instanceof NyxWraith || z instanceof CrystalBrute).size();
                if (near >= 7) continue;
                for (int attempt = 0; attempt < 6; attempt++) {
                    double ang = r.nextDouble() * Math.PI * 2;
                    double dist = 22 + r.nextInt(20);
                    int x = p.blockPosition().getX() + (int) (Math.cos(ang) * dist);
                    int z = p.blockPosition().getZ() + (int) (Math.sin(ang) * dist);
                    if (!nyx.hasChunk(x >> 4, z >> 4)) continue;
                    int y = nyx.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                    BlockPos pos = new BlockPos(x, y, z);
                    if (nyx.getBrightness(LightLayer.BLOCK, pos) >= 8) continue;
                    if (nyx.getBlockState(pos.below()).isAir() || !nyx.getFluidState(pos).isEmpty()) continue;
                    EntityType<? extends Zombie> type = r.nextInt(100) < 65 ? ModEntities.NYX_WRAITH : ModEntities.CRYSTAL_BRUTE;
                    if (type.spawn(nyx, pos, EntitySpawnReason.NATURAL) != null) break;
                }
            }
        });
    }
}

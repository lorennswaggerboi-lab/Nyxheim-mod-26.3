package com.nyxheim.registry;

import com.nyxheim.Nyxheim;
import com.nyxheim.entity.CrystalBrute;
import com.nyxheim.entity.NyxColossus;
import com.nyxheim.entity.NyxWraith;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
    public static final EntityType<NyxWraith> NYX_WRAITH = reg("nyx_wraith",
            EntityType.Builder.of(NyxWraith::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8));
    public static final EntityType<CrystalBrute> CRYSTAL_BRUTE = reg("crystal_brute",
            EntityType.Builder.of(CrystalBrute::new, MobCategory.MONSTER).sized(0.8f, 2.3f).clientTrackingRange(8));
    public static final EntityType<NyxColossus> NYX_COLOSSUS = reg("nyx_colossus",
            EntityType.Builder.of(NyxColossus::new, MobCategory.MONSTER).sized(0.6f, 1.95f).fireImmune().clientTrackingRange(12));

    private static <T extends net.minecraft.world.entity.Entity> EntityType<T> reg(String name, EntityType.Builder<T> builder) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, Nyxheim.id(name));
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(NYX_WRAITH, NyxWraith.createAttributes());
        FabricDefaultAttributeRegistry.register(CRYSTAL_BRUTE, CrystalBrute.createAttributes());
        FabricDefaultAttributeRegistry.register(NYX_COLOSSUS, NyxColossus.createAttributes());
    }
}

package com.nyxheim.client;

import com.nyxheim.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class NyxheimClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.NYX_WRAITH, ctx -> new NyxZombieRenderer(ctx, "nyx_wraith"));
        EntityRendererRegistry.register(ModEntities.CRYSTAL_BRUTE, ctx -> new NyxZombieRenderer(ctx, "crystal_brute"));
        EntityRendererRegistry.register(ModEntities.NYX_COLOSSUS, ctx -> new NyxZombieRenderer(ctx, "nyx_colossus"));
    }
}

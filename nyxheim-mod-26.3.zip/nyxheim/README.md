# Nyxheim — mod de dimensión para Minecraft 26.3 (Fabric)

Una dimensión enorme y oscura con portal carísimo, minerales nuevos, 3 enemigos (uno es jefe), estructuras y herramientas.

## Compilar en Linux

```bash
# 1) Java 25 (con SDKMAN)
curl -s "https://get.sdkman.io" | bash && source ~/.sdkman/bin/sdkman-init.sh
sdk install java 25-tem
# 2) Gradle 9.7.1 (solo para generar el wrapper una vez)
sdk install gradle 9.7.1
cd nyxheim && gradle wrapper --gradle-version 9.7.1
# 3) Compilar
./gradlew build
# Resultado: build/libs/nyxheim-0.1.0.jar  -> a la carpeta mods/ junto a Fabric API 0.162.0+26.3
```
Para probar en desarrollo: `./gradlew runClient`.

## Cómo jugar
1. **Marco** (6 ancho × 7 alto, vertical): 4 esquinas de **Núcleo de Nyx**, 18 bloques de **Obsidiana Rúnica**, interior 4×5 vacío.
2. **Ojo de Nyx** (clic derecho sobre el marco): enciende el portal. Párate dentro ~4 s.
3. Recetas difíciles a propósito (ver `data/nyxheim/recipe`): Obsidiana rúnica = 4 obsidiana llorona + 4 obsidiana + fragmento de eco; Núcleo = 4 netherita + 4 bloques de diamante + tótem; Ojo = estrella del Nether + aliento de dragón + corazón del mar + fragmento de eco + netherita.
4. En Nyxheim: minerales (voidita, lunarita), Obeliscos, Criptas (con spawner y 2 cofres) y Anillos Antiguos. **Sigilo de Nyx** invoca al Coloso (jefe).

## Probar rápido (creativo)
`/give @s nyxheim:eye_of_nyx`, `/give @s nyxheim:runed_obsidian 18`, `/give @s nyxheim:nyx_core_block 4`, `/summon nyxheim:nyx_colossus`.

## Notas importantes
- **No pude compilar esto en mi entorno** (sin acceso a internet para bajar Minecraft). Escribí el código con las APIs de 26.1–26.3 que pude verificar, pero puede haber 1–3 errores de nombres/imports. Si `./gradlew build` falla, pegame el error y lo corrijo.
- Posible ajuste: si `net.minecraft.world.entity.monster.zombie.Zombie` no existe, probá `net.minecraft.world.entity.monster.Zombie` (en `entity/*.java`, `NyxSpawner`).
- La dimensión usa los biomas vanilla con terreno amplificado; el contenido propio (piedra, minerales, estructuras) se aplica al generar cada chunk por código. Por eso también pueden aparecer estructuras vanilla (aldeas, etc.).
- Armaduras, más herramientas, pasivos y shaders quedan para una siguiente versión.

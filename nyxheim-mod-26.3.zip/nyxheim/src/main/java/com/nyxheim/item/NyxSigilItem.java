package com.nyxheim.item;

import com.nyxheim.Nyxheim;
import com.nyxheim.entity.NyxColossus;
import com.nyxheim.registry.ModEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

/** Invoca al jefe, el Coloso de Nyx. Solo funciona dentro de la dimensión. */
public class NyxSigilItem extends Item {
    public NyxSigilItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (!(context.getLevel() instanceof ServerLevel level)) {
            return InteractionResult.SUCCESS;
        }
        Player player = context.getPlayer();
        if (!level.dimension().equals(Nyxheim.NYX)) {
            if (player != null) player.displayClientMessage(Component.translatable("message.nyxheim.sigil_wrong_dim"), true);
            return InteractionResult.FAIL;
        }
        NyxColossus boss = ModEntities.NYX_COLOSSUS.spawn(level, context.getClickedPos().above(), EntitySpawnReason.MOB_SUMMONED);
        if (boss == null) return InteractionResult.FAIL;
        if (player != null && !player.getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.SUCCESS;
    }
}
